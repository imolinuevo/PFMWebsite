<?php
 defined('BASEPATH') OR exit('No direct script access allowed');
 
 $config['admin_password'] = 'a8f5f167f44f4964e6c998dee827110c';